#ifndef PRUEBASAUXDEFENSA_H
#define PRUEBASAUXDEFENSA_H

#include "Defensa.h"
#include "FuncAux.h"

#endif