#pragma once

//PRE:-
// POs: retorna un entero con el valor del contador 
int funcionPrueba();

//PRE: Recibe 2 enteros y el divis != 0
//Pos: retorna el resultado de la division.
int dividir(int div, int divis);

void codigoPrimeraClase();